package com.example.railwayticketmanagementsystem;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.*;
import java.time.LocalDate;

public class bookTicketController {
    @FXML
    private TextField train_no_textfield;
    @FXML
    private TextField train_name_textfield;
    @FXML
    private TextField passenger_no_textfield;
    @FXML
    private TextField classTextField;
    @FXML
    private DatePicker Date;

    @FXML
    public void initialize() {
        Date.setDayCellFactory(picker -> new javafx.scene.control.DateCell() {
            @Override
            public void updateItem(LocalDate item, boolean empty) {
                super.updateItem(item, empty);
                if (item.isBefore(LocalDate.now())) {
                    setDisable(true);
                }
            }
        });

        // Listener to handle date selection
        Date.valueProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue != null) {
                initializeDateAvailability(newValue.toString());
            }
        });
    }

    // Ensure the date is initialized in the database
    private void initializeDateAvailability(String travelDate) {
        String trainNo = train_no_textfield.getText().trim();
        String trainClass = classTextField.getText().trim();
        String trainName = train_name_textfield.getText().trim();

        if (trainNo.isEmpty() || trainClass.isEmpty()) {
            return; // Date initialization depends on these fields
        }

        try (Connection connectDB = new DatabaseConnection().getConnection()) {
            String query = "SELECT available_seats FROM train_seat_availability WHERE train_no = ? AND train_name = ? AND train_class = ? AND travel_date = ?";
            try (PreparedStatement stmt = connectDB.prepareStatement(query)) {
                stmt.setInt(1, Integer.parseInt(trainNo));  // `train_no` is an integer
                stmt.setString(2, trainName);              // `train_name` is a varchar
                stmt.setString(3, trainClass);             // `train_class` is a varchar
                stmt.setDate(4, java.sql.Date.valueOf(travelDate)); // `travel_date` is a date

                ResultSet rs = stmt.executeQuery();
                if (!rs.next()) {
                    initializeSeatForDate(connectDB, trainNo, trainClass, travelDate, trainName);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Database Error", "Failed to initialize date availability: " + e.getMessage());
        }

    }

   private void initializeSeatForDate(Connection connectDB, String trainNo, String trainClass, String travelDate, String trainName) throws SQLException {
        String seatQuery = "SELECT available_tickets FROM trains WHERE train_no = ? AND train_name = ? AND class = ?";
        try (PreparedStatement seatStmt = connectDB.prepareStatement(seatQuery)) {
            seatStmt.setString(1, trainNo);
            seatStmt.setString(2, trainName);
            seatStmt.setString(3, trainClass);
            ResultSet rs = seatStmt.executeQuery();
            if (rs.next()) {
                int defaultSeats = rs.getInt("available_tickets");
                String insertQuery = "INSERT INTO train_seat_availability (train_no, train_name, train_class, travel_date, available_seats) VALUES (?, ?, ?, ?, ?)";
                try (PreparedStatement insertStmt = connectDB.prepareStatement(insertQuery)) {
                    insertStmt.setString(1, trainNo);
                    insertStmt.setString(2, trainName);
                    insertStmt.setString(3, trainClass);
                    insertStmt.setString(4, travelDate);
                    insertStmt.setInt(5, defaultSeats);
                    insertStmt.executeUpdate();
                }
            }
        }
    }



    @FXML
    public void book_TicketOnAction(ActionEvent event) {
        String trainNo = train_no_textfield.getText().trim();
        String trainName = train_name_textfield.getText().trim();
        String trainClass = classTextField.getText().trim();
        String travelDate = (Date.getValue() != null) ? Date.getValue().toString() : null;

        if (!validateInput(trainNo, trainName, trainClass, travelDate)) {
            return;
        }

        int passengers = parsePassengers();
        if (passengers == -1) return; // Invalid passenger input
        initializeDateAvailability(travelDate);
        try (Connection connectDB = new DatabaseConnection().getConnection()) {
            if (isSeatAvailableForDate(connectDB, trainNo, trainClass, passengers, travelDate)) {
                double totalPrice = processBooking(connectDB, trainNo, trainName, trainClass, travelDate, passengers);
                showAlert(Alert.AlertType.INFORMATION, "Booking Successful", "Total price: Taka " + totalPrice);
            }
        } catch (Exception e) {
            showAlert(Alert.AlertType.ERROR, "Database Error", "An error occurred: " + e.getMessage());
        }
    }

    private boolean validateInput(String trainNo, String trainName, String trainClass, String travelDate) {
        if (trainNo.isEmpty() || trainName.isEmpty() || trainClass.isEmpty() || travelDate == null) {
            showAlert(Alert.AlertType.ERROR, "Missing Fields", "Please fill in all fields.");
            return false;
        }
        return true;
    }

    private int parsePassengers() {
        try {
            return Integer.parseInt(passenger_no_textfield.getText().trim());
        } catch (NumberFormatException e) {
            showAlert(Alert.AlertType.ERROR, "Invalid Input", "Please enter a valid number of passengers.");
            return -1;
        }
    }

    private boolean isSeatAvailableForDate(Connection connectDB, String trainNo, String trainClass, int passengers, String travelDate) throws SQLException {
        String trainName = train_name_textfield.getText().trim();

        if (trainName.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Missing Train Name", "Please enter the Train Name.");
            return false;
        }

        String query = "SELECT available_seats FROM train_seat_availability WHERE train_no = ? AND train_class = ? AND travel_date = ? AND train_name = ?";
        try (PreparedStatement stmt = connectDB.prepareStatement(query)) {
            stmt.setString(1, trainNo);
            stmt.setString(2, trainClass);
            stmt.setString(3, travelDate);
            stmt.setString(4, trainName);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                int availableSeats = rs.getInt("available_seats");
                if (availableSeats >= passengers) {
                    return true;
                } else {
                    showAlert(Alert.AlertType.ERROR, "Insufficient Seats", "Only " + availableSeats + " seats are available for this date.");
                    return false;
                }
            } else {
                showAlert(Alert.AlertType.ERROR, "No Data Found", "No seat availability information found for the selected date.");
                return false;
            }
        }
    }

    private double processBooking(Connection connectDB, String trainNo, String trainName, String trainClass, String travelDate, int passengers) throws SQLException {
        double totalPrice = 0;


        String seatQuery = "SELECT price,departure,destination,departure_time FROM trains WHERE train_no = ? AND class = ?";
        try (PreparedStatement seatStmt = connectDB.prepareStatement(seatQuery)) {
            seatStmt.setString(1, trainNo);
            seatStmt.setString(2, trainClass);
            ResultSet rs = seatStmt.executeQuery();
            if (rs.next()) {
                totalPrice = passengers * rs.getDouble("price");
                String departure=rs.getString("departure");
                String destination=rs.getString("destination");
                String departure_time=rs.getString("departure_time");


                updateSeatAvailability(connectDB, trainNo, trainClass, travelDate, passengers, trainName);
                insertTicket(connectDB, trainNo, trainName, trainClass, travelDate, passengers, totalPrice,departure,destination,departure_time);
            }
        }
        return totalPrice;
    }

    private void updateSeatAvailability(Connection connectDB, String trainNo, String trainClass, String travelDate, int passengers, String trainName) throws SQLException {
        String updateQuery = "UPDATE train_seat_availability SET available_seats = available_seats - ? WHERE train_no = ? AND train_name = ? AND train_class = ? AND travel_date = ?";
        try (PreparedStatement updateStmt = connectDB.prepareStatement(updateQuery)) {
            updateStmt.setInt(1, passengers);
            updateStmt.setString(2, trainNo);
            updateStmt.setString(3, trainName);
            updateStmt.setString(4, trainClass);
            updateStmt.setString(5, travelDate);
            updateStmt.executeUpdate();
        }
    }

    private void insertTicket(Connection connectDB, String trainNo, String trainName, String trainClass, String travelDate, int passengers, double totalPrice,String departure,String destination,String departureTime) throws SQLException {
        String username = UserLoginPageController.loggedInUsername;
        int userId = UserLoginPageController.loggedInUserId;


        String insertTicketQuery = "INSERT INTO tickets (account_id, username, train_no , train_name , departure, destination, train_class, departure_time, number_of_seats, price,date) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement ticketStmt = connectDB.prepareStatement(insertTicketQuery, Statement.RETURN_GENERATED_KEYS)) {


            ticketStmt.setInt(1, userId);
            ticketStmt.setString(2, username);
            ticketStmt.setInt(3, Integer.parseInt(trainNo));
            ticketStmt.setString(4, trainName);
            ticketStmt.setString(5, departure);
            ticketStmt.setString(6, destination);
            ticketStmt.setString(7, trainClass);
            ticketStmt.setString(8, departureTime);
            ticketStmt.setInt(9, passengers);
            ticketStmt.setDouble(10, totalPrice);
            ticketStmt.setString(11, travelDate);
            int affectedRows = ticketStmt.executeUpdate();
            if (affectedRows > 0) {
                ResultSet generatedKeys = ticketStmt.getGeneratedKeys();
                if (generatedKeys.next()) {
                    int ticketId = generatedKeys.getInt(1);
                    showAlert(Alert.AlertType.INFORMATION, "Ticket Booked", "Your ticket ID is: " + ticketId);
                }
            }
        }
    }

    @FXML
    public void backButtonOnAction(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("trainSearch.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
    }

    private void showAlert(Alert.AlertType alertType, String title, String content) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
