package com.example.railwayticketmanagementsystem;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;

public class myTicketsController {
    @FXML
    private ScrollPane scrollPane;
    @FXML
    private VBox ticketBox;
    @FXML
    private Button backButton;

    @FXML
    public void initialize() {

        loadTickets();
    }
    private void loadTickets() {
        ticketBox.getChildren().clear();

        LocalDate currentDate = LocalDate.now();

        DatabaseConnection connectNow = new DatabaseConnection();
        try (Connection connectDB = connectNow.getConnection()) {

            String username = UserLoginPageController.loggedInUsername;
            int userId = UserLoginPageController.loggedInUserId;

            String query = "SELECT ticket_id, train_no ,train_name, departure, destination, train_class, departure_time, " +
                    "number_of_seats, price, date FROM tickets WHERE account_id = ? AND username = ? AND date > ?";
            try (PreparedStatement statement = connectDB.prepareStatement(query)) {
                statement.setInt(1, userId);
                statement.setString(2, username);
                statement.setString(3, currentDate.toString());
                ResultSet resultSet = statement.executeQuery();

                while (resultSet.next()) {
                    HBox ticketBoxItem = createTicketBoxItem(
                            resultSet.getInt("ticket_id"),
                            resultSet.getInt("train_no"),
                            resultSet.getString("train_name"),
                            resultSet.getString("departure"),
                            resultSet.getString("destination"),
                            resultSet.getString("train_class"),
                            resultSet.getString("departure_time"),
                            resultSet.getInt("number_of_seats"),
                            resultSet.getDouble("price"),
                            resultSet.getString("date")
                    );
                    ticketBox.getChildren().add(ticketBoxItem);
                }
            }
        } catch (Exception e) {
            showAlert(Alert.AlertType.ERROR, "Database Error", "Failed to load tickets: " + e.getMessage());
        }
    }
    private HBox createTicketBoxItem(int ticketId,int train_no, String trainName, String departure, String destination,
                                     String trainClass, String departureTime, int numberOfSeats,
                                     double price, String travelDate) {
        HBox ticketItem = new HBox(10);
        ticketItem.setStyle("-fx-padding: 10; -fx-background-color: #f4f4f4; -fx-border-radius: 10; -fx-border-width: 1;");
        ticketItem.setMaxWidth(Double.MAX_VALUE);


        GridPane ticketGrid = new GridPane();

        ticketGrid.setStyle("-fx-border-color: black;-fx-background-color: #94d8d8; -fx-border-width: 2; -fx-padding: 20; -fx-border-radius: 5;");

        ticketGrid.setHgap(15);
        ticketGrid.setVgap(8);

        Text titleText = new Text("Your Journey Information");
        titleText.setFont(Font.font("Arial", 16));
        titleText.setFill(Color.BLUE);
        ticketGrid.add(titleText, 0, 0, 2, 1);

        ticketGrid.add(new Text("Ticket ID:"), 0, 1);
        ticketGrid.add(new Text(String.valueOf(ticketId)),1,1);
        ticketGrid.add(new Text("Train No:"), 0, 2);
        ticketGrid.add(new Text(String.valueOf(train_no)),1,2);

        ticketGrid.add(new Text("Train:"), 0, 3);
        ticketGrid.add(new Text(trainName), 1, 3);

        ticketGrid.add(new Text("From:"), 0, 4);
        ticketGrid.add(new Text(departure), 1, 4);

        ticketGrid.add(new Text("To:"), 0, 5);
        ticketGrid.add(new Text(destination), 1, 5);

        ticketGrid.add(new Text("Class:"), 0, 6);
        ticketGrid.add(new Text(trainClass), 1, 6);

        ticketGrid.add(new Text("Departure:"), 0, 7);
        ticketGrid.add(new Text(departureTime), 1, 7);

        ticketGrid.add(new Text("Seats:"), 0, 8);
        ticketGrid.add(new Text(String.valueOf(numberOfSeats)), 1, 8);

        ticketGrid.add(new Text("Fare:"), 0, 9);
        ticketGrid.add(new Text( String.valueOf(price)+" Taka"), 1, 9);

        ticketGrid.add(new Text("Date:"), 0, 10);
        ticketGrid.add(new Text(travelDate), 1, 10);


        ticketItem.getChildren().add(ticketGrid);



        return ticketItem;
    }

    @FXML
    private void backButtonOnAction(javafx.event.ActionEvent event) throws IOException {

        FXMLLoader loader = new FXMLLoader(getClass().getResource("trainSearch.fxml"));
        Parent root = loader.load();
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
    }

    private void showAlert(Alert.AlertType alertType, String title, String content) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setContentText(content);
        alert.showAndWait();
    }
}






