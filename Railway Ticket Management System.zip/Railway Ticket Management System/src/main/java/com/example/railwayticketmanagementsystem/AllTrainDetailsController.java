package com.example.railwayticketmanagementsystem;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.scene.control.Button;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class AllTrainDetailsController {

    @FXML
    private TableView<Train> trainTable;


    @FXML
    private TableColumn<Train, String> trainNoColumn;
    @FXML
    private TableColumn<Train, String> trainNameColumn;
    @FXML
    private TableColumn<Train, String> departureColumn;
    @FXML
    private TableColumn<Train, String> arrivalColumn;
    @FXML
    private TableColumn<Train, Double> priceColumn;
    @FXML
    private TableColumn<Train, String> classColumn;
    @FXML
    private TableColumn<Train, Integer> availableTicketsColumn;
    @FXML
    private TableColumn<Train, String> destinationColumn;  // Added column for destination
    @FXML
    private TableColumn<Train, String> departureTimeColumn; // Added column for departure time

    @FXML
    private Button BackButton;

    public void initialize() {
        // Set up columns to match Train object properties

        trainNoColumn.setCellValueFactory(new PropertyValueFactory<>("trainNo"));
        trainNameColumn.setCellValueFactory(new PropertyValueFactory<>("trainName"));
        departureColumn.setCellValueFactory(new PropertyValueFactory<>("departure"));
        destinationColumn.setCellValueFactory(new PropertyValueFactory<>("destination"));
        departureTimeColumn.setCellValueFactory(new PropertyValueFactory<>("departureTime"));
        arrivalColumn.setCellValueFactory(new PropertyValueFactory<>("arrival"));
        priceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));
        classColumn.setCellValueFactory(new PropertyValueFactory<>("trainClass"));
        availableTicketsColumn.setCellValueFactory(new PropertyValueFactory<>("availableTickets"));
          // Bind destination
        // Bind departure time

        // Load train data from the database
        loadTrainData();
    }

    private void loadTrainData() {
        try {
            // Database connection using DatabaseConnection class
            DatabaseConnection dbConnection = new DatabaseConnection();
            Connection conn = dbConnection.getConnection();
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM trains");

            // Clear the existing items before adding the updated list
            trainTable.getItems().clear();

            while (rs.next()) {
                // Create a Train object from the result set
                Train train = new Train(
                        rs.getString("serial_no"),    // Assuming serial_no is in the database
                        rs.getString("train_no"),
                        rs.getString("train_name"),
                        rs.getString("departure"),
                        rs.getString("destination"),
                        rs.getString("arrival"),
                        rs.getString("departure_time"),
                        rs.getDouble("price"),
                        rs.getString("class"),
                        rs.getInt("available_tickets")

                );

                // Add the train to the table
                trainTable.getItems().add(train);
            }

            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleBackButton() {
        // Close the current window
        Stage stage = (Stage) BackButton.getScene().getWindow();
        stage.close();
    }
}

