package com.example.railwayticketmanagementsystem;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class RemovePageController {

    @FXML
    private TextField trainNoField;

    @FXML
    private void handleRemove() {
        String trainNo = trainNoField.getText().trim(); // Get the entered train number and trim spaces

        if (trainNo.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Input Error", "Train number cannot be empty!");
            return;
        }

        // Database deletion logic
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/railway", "root", "mysql03")) {
            String sql = "DELETE FROM trains WHERE train_no = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, trainNo);

            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected > 0) {
                showAlert(Alert.AlertType.INFORMATION, "Success", "Train with Train No: " + trainNo + " has been successfully removed.");
                trainNoField.clear(); // Clear the input field after success
            } else {
                showAlert(Alert.AlertType.WARNING, "Not Found", "No train found with the Train No: " + trainNo + ".");
            }

        } catch (Exception e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Database Error", "An error occurred while trying to remove the train. Please try again.");
        }
    }

    private void showAlert(Alert.AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
