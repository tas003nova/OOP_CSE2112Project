package com.example.railwayticketmanagementsystem;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import java.io.IOException;

public class AdminLoginPageController {

    @FXML
    private TextField usernameField;

    @FXML
    private PasswordField passwordField;
    @FXML
    private Button BackButton;
    @FXML
    private Button LoginButton;
    @FXML
    private void handleBackButton() {
        try {
            // Load the Home page
            FXMLLoader loader = new FXMLLoader(getClass().getResource("hello-view.fxml"));
            Scene homeScene = new Scene(loader.load());
            Stage stage = (Stage) BackButton.getScene().getWindow();
            stage.setScene(homeScene);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleLoginButton() {
        String username = usernameField.getText();
        String password = passwordField.getText();

        // Check username and password
        if (username.equals("Admin") && password.equals("1234")) {
            try {
                // Load the Admin Dashboard page
                FXMLLoader loader = new FXMLLoader(getClass().getResource("AdminDashboard.fxml"));
                Scene dashboardScene = new Scene(loader.load());
                Stage stage = (Stage) LoginButton.getScene().getWindow();
                stage.setScene(dashboardScene);
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            // Show an alert for invalid credentials
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Login Failed");
            alert.setHeaderText("Invalid Credentials");
            alert.setContentText("The username or password is incorrect. Please try again.");
            alert.showAndWait();
        }
    }
}

