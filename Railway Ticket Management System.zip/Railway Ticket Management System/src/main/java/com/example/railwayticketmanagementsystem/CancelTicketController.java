package com.example.railwayticketmanagementsystem;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class CancelTicketController {

    @FXML
    private TextField ticketIdTextField;
    @FXML

    private final String username = UserLoginPageController.loggedInUsername;
    private final int userId = UserLoginPageController.loggedInUserId;

    private void deleteTicket() {
        String ticketIdString = ticketIdTextField.getText().trim();

        if (ticketIdString.isEmpty()) {
            showAlert(Alert.AlertType.WARNING, "Input Error", "Ticket ID is required!");
            return;
        }
        int ticketId = Integer.parseInt(ticketIdString);

        DatabaseConnection connectNow = new DatabaseConnection();
        try (Connection connectDB = connectNow.getConnection()) {
            String checkQuery = "SELECT ticket_id FROM tickets WHERE ticket_id = ? AND username = ? AND account_id = ?";
            try (PreparedStatement checkStmt = connectDB.prepareStatement(checkQuery)) {
                checkStmt.setInt(1, ticketId);
                checkStmt.setString(2, username);
                checkStmt.setInt(3, userId);
                ResultSet resultSet = checkStmt.executeQuery();

                if (resultSet.next()) {
                    // If the ticket exists for this user, delete it
                    String deleteQuery = "DELETE FROM tickets WHERE ticket_id = ? AND username = ? AND account_id = ?";
                    try (PreparedStatement deleteStmt = connectDB.prepareStatement(deleteQuery)) {
                        deleteStmt.setInt(1, ticketId);
                        deleteStmt.setString(2, username);
                        deleteStmt.setInt(3, userId);

                        int rowsAffected = deleteStmt.executeUpdate();
                        if (rowsAffected > 0) {
                            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                            alert.setTitle("Cancel Ticket Confirmation");
                            alert.setContentText("Are you sure you want to cancel the ticket?");
                            if (alert.showAndWait().get() == ButtonType.OK) {
                                showAlert(Alert.AlertType.INFORMATION, "Success", "Ticket cancelled successfully!");
                            }
                        } else {
                            showAlert(Alert.AlertType.ERROR, "Error", "Ticket deletion failed.");
                        }
                    }
                } else {
                    showAlert(Alert.AlertType.WARNING, "Not Found", "Ticket not found for the given ID and user.");
                }
            }
        } catch (Exception e) {
            showAlert(Alert.AlertType.ERROR, "Database Error", "Failed to delete the ticket: " + e.getMessage());
        }
    }

    private void showAlert(Alert.AlertType alertType, String title, String content) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setContentText(content);
        alert.showAndWait();
    }

public void cancelOnAction(ActionEvent event) throws IOException {
        deleteTicket();

}
    public void backButtonOnAction(ActionEvent event) throws IOException{
        FXMLLoader loader=new FXMLLoader(getClass().getResource("trainSearch.fxml"));
        Parent root=loader.load();
        Stage stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        stage.setScene((new Scene(root)));
    }

}
