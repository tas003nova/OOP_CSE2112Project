package com.example.railwayticketmanagementsystem;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.io.IOException;

public class AdminDashboardController {
    @FXML
    private Button BackButton;

    @FXML
    private Button AddTrainButton;

    @FXML
    private Button RemoveTrainButton;

    @FXML
    private Button UpdateTrainButton;

    @FXML
    private BorderPane contentArea; // The content area where forms will load

    // Method to handle the "Add Train" button
    @FXML
    private void handleAddTrainButton() {
        try {
            // Load the AddTrain.fxml file
            FXMLLoader loader = new FXMLLoader(getClass().getResource("AddTrainPage.fxml"));
            Pane addTrainPane = loader.load();  // Load the form from FXML

            // Set the AddTrain.fxml content to the center of the contentArea (BorderPane)
            contentArea.setCenter(addTrainPane);
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Error loading AddTrain.fxml: " + e.getMessage());
        }
    }
    @FXML
    private void handleRemoveTrainButton() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("RemovePage.fxml"));
            Pane removeTrainPane = loader.load();
            contentArea.setCenter(removeTrainPane); // Load RemovePage into contentArea
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Error loading RemovePage.fxml: " + e.getMessage());
        }
    }
    @FXML
    public void handleShowIncomeButton() {
        try {
            // Load the ShowIncomeFXML file
            FXMLLoader loader = new FXMLLoader(getClass().getResource("ShowIncome.fxml"));
            Pane showIncomePane = loader.load();

            // Set the loaded pane into the BorderPane
            contentArea.setCenter(showIncomePane);
        } catch (IOException e) {
            e.printStackTrace();
            // Optionally, log or show an error dialog to the user
        }
    }
    @FXML
    private void handleUpdateTrainButton() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("UpdatePage.fxml"));
            Pane removeTrainPane = loader.load();
            contentArea.setCenter(removeTrainPane); // Load RemovePage into contentArea
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Error loading UpdatePage.fxml: " + e.getMessage());
        }
    }


    @FXML
    private void handleAllTrainDetailsButton() {
        try {
            // Load the AllTrainDetails.fxml file
            FXMLLoader loader = new FXMLLoader(getClass().getResource("AllTrainDetails.fxml"));
            Pane allTrainDetailsPane = loader.load();  // Load the form from FXML

            // Create a new Stage for the new window
            Stage newStage = new Stage();
            Scene newScene = new Scene(allTrainDetailsPane);
            newStage.setScene(newScene);

            // Set the title and show the new window
            newStage.setTitle("All Train Details");
            newStage.show();
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Error loading AllTrainDetails.fxml: " + e.getMessage());
        }
    }

    @FXML
    private void handleBackButton() {
        try {
            // Load the Home page
            FXMLLoader loader = new FXMLLoader(getClass().getResource("hello-view.fxml"));
            Scene homeScene = new Scene(loader.load());
            Stage stage = (Stage) BackButton.getScene().getWindow();
            stage.setScene(homeScene);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
