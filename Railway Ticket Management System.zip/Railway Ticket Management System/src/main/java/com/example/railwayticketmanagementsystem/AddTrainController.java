package com.example.railwayticketmanagementsystem;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class AddTrainController {

    @FXML
    private TextField serialNoField;
    @FXML
    private TextField trainNoField;
    @FXML
    private TextField trainNameField;
    @FXML
    private TextField departureField;
    @FXML
    private TextField destinationField;
    @FXML
    private TextField classField;
    @FXML
    private TextField priceField;
    @FXML
    private TextField arrivalField;
    @FXML
    private TextField departureTimeField;
    @FXML
    private TextField availableTicketsField;

    // Database connection details
    private static final String DATABASE_URL = "jdbc:mysql://localhost:3306/railway";
    private static final String DATABASE_USER = "root";
    private static final String DATABASE_PASSWORD = "mysql03"; // Replace with your MySQL password

    @FXML
    private void handleAdd() {
        String serialNo=serialNoField.getText();
        String trainNo = trainNoField.getText();
        String trainName = trainNameField.getText();
        String departure = departureField.getText();
        String destination = destinationField.getText();
        String trainClass = classField.getText();
        String price = priceField.getText();
        String arrival = arrivalField.getText();
        String departureTime = departureTimeField.getText();
        String availableTickets = availableTicketsField.getText();

        // Input validation
        if ( serialNo.isEmpty()||trainNo.isEmpty() || trainName.isEmpty() || departure.isEmpty() ||
                destination.isEmpty() || trainClass.isEmpty() || price.isEmpty() ||
                arrival.isEmpty() || departureTime.isEmpty() || availableTickets.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Validation Error", "All fields must be filled out.");
            return;
        }

        try {
            // Database connection
            Connection connection = DriverManager.getConnection(DATABASE_URL, DATABASE_USER, DATABASE_PASSWORD);

            // Insert query
            String query = "INSERT INTO trains (serial_no,train_no, train_name, departure, destination, class, price, arrival, departure_time, available_tickets) " +
                    "VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(query);

            // Setting the values
            statement.setString(1, serialNo);
            statement.setString(2, trainNo);
            statement.setString(3, trainName);
            statement.setString(4, departure);
            statement.setString(5, destination);
            statement.setString(6, trainClass);
            statement.setString(7, price);
            statement.setString(8, arrival);
            statement.setString(9, departureTime);
            statement.setString(10, availableTickets);

            // Execute the query
            int rowsInserted = statement.executeUpdate();

            if (rowsInserted > 0) {
                showAlert(Alert.AlertType.INFORMATION, "Success", "Train added successfully!");
                clearFields(); // Clear fields after successful addition
            }

            // Close connection
            statement.close();
            connection.close();

        } catch (Exception e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Database Error", "An error occurred while adding the train.");
        }
    }

    // Method to display alerts
    private void showAlert(Alert.AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.showAndWait();
    }

    // Method to clear all input fields
    private void clearFields() {
        serialNoField.clear();
        trainNoField.clear();
        trainNameField.clear();
        departureField.clear();
        destinationField.clear();
        classField.clear();
        priceField.clear();
        arrivalField.clear();
        departureTimeField.clear();
        availableTicketsField.clear();
    }
}
