package com.example.railwayticketmanagementsystem;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.fxml.FXMLLoader;
import java.io.IOException;
import java.sql.*;

public class UpdatePageController {

    @FXML
    private TextField trainNoField;

    // Handle the Update button click to check if the train number exists in the database
    @FXML
    public void handleUpdate() {
        String trainNo = trainNoField.getText().trim();

        if (trainNo.isEmpty()) {
            showAlert("Error", "Please enter a train number.");
            return;
        }

        // Check if the train number exists in the database
        if (checkTrainExists(trainNo)) {
            // If the train exists, open the UpdateTrainDetails page
            openUpdateTrainDetailsPage(trainNo);
        } else {
            // If the train doesn't exist, show an error
            showAlert("Error", "Train number not found in the database.");
        }
    }

    // Check if the train number exists in the database
    private boolean checkTrainExists(String trainNo) {
        boolean exists = false;
        // Database connection details
        String url = "jdbc:mysql://localhost:3306/railway";
        String username = "root";
        String password = "mysql03";

        String query = "SELECT COUNT(*) FROM trains WHERE train_no = ?";

        try (Connection conn = DriverManager.getConnection(url, username, password);
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, trainNo);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                int count = rs.getInt(1);
                exists = count > 0;  // If count > 0, the train exists
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return exists;
    }

    // Open the UpdateTrainDetails.fxml page in a new window
    private void openUpdateTrainDetailsPage(String trainNo) {
        try {
            // Load the UpdateTrainDetails.fxml
            FXMLLoader loader = new FXMLLoader(getClass().getResource("UpdateTrainDetails.fxml"));
            AnchorPane updatePage = loader.load();

            // Get the controller and pass the train number
            UpdateTrainDetailsController controller = loader.getController();
            controller.loadTrainDetails(trainNo);

            // Create a new stage and show the update page
            Stage stage = new Stage();
            stage.setTitle("Update Train Details");
            stage.setScene(new Scene(updatePage));
            stage.show();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Show an alert with a given title and message
    private void showAlert(String title, String message) {
        Alert alert = new Alert(AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
