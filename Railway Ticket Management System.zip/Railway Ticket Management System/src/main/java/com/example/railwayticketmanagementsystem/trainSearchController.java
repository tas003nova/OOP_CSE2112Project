package com.example.railwayticketmanagementsystem;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class trainSearchController {

    @FXML
    private ComboBox<String> fromComboBox;

    @FXML
    private ComboBox<String> toComboBox;

    @FXML
    private ComboBox<String> classComboBox;

    private List<Train> searchResults = new ArrayList<>();

    @FXML
    private Label welcomeLabel;

    // Method to set the username dynamically
    public void setUsername(String username) {
        welcomeLabel.setText("Welcome " + username);
    }
    @FXML
    public void initialize() {
        // Populate station options
        ObservableList<String> stations = FXCollections.observableArrayList(
                "Dhaka", "Sylhet", "Brahmanbaria", "Chattogram"
        );
        fromComboBox.setItems(stations);
        toComboBox.setItems(stations);

        // Populate class options
        ObservableList<String> classes = FXCollections.observableArrayList(
                "shovon", "S_Chair", "f_class"
        );
        classComboBox.setItems(classes);
    }

    @FXML
    public void searchButtonOnAction(ActionEvent event) {
        String fromStation = fromComboBox.getValue();
        String toStation = toComboBox.getValue();
        String selectedClass = classComboBox.getValue();

        // Validate input
        if (fromStation == null || toStation == null || selectedClass == null) {
            showAlert("Error", "Please select 'From', 'To', and 'Class' before searching.");
            return;
        }

        // Query the database for matching trains
        DatabaseConnection connectNow = new DatabaseConnection();
        Connection connectDB = connectNow.getConnection();

        String searchQuery = "SELECT * FROM trains WHERE departure = ? AND destination = ? AND class = ?";

        try (PreparedStatement statement = connectDB.prepareStatement(searchQuery)) {
            statement.setString(1, fromStation);
            statement.setString(2, toStation);
            statement.setString(3, selectedClass);

            ResultSet resultSet = statement.executeQuery();

            if (!resultSet.isBeforeFirst()) {
                showAlert("No Trains Found", "No trains available for the selected route and class.");
                return;
            }

            // Clear previous results and populate the list with new search results
            searchResults.clear();
            while (resultSet.next()) {
                Train train = new Train(
                        resultSet.getString("serial_no"),
                        resultSet.getString("train_no"),
                        resultSet.getString("train_name"),
                        resultSet.getString("departure"),
                        resultSet.getString("destination"),
                        resultSet.getString("arrival"),
                        resultSet.getString("departure_Time"),
                        resultSet.getDouble("price"),
                        resultSet.getString("class"),
                        resultSet.getInt("available_Tickets")
                );
                searchResults.add(train);
            }

            // Open the train details window and pass the search results
            openTrainDetailsWindow();

        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Error", "An error occurred while searching for trains. Please try again.");
        }
    }

    private void openTrainDetailsWindow() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("showTrainDetails.fxml"));
            Stage stage = new Stage();
            stage.setScene(new Scene(loader.load()));
            stage.setTitle("Train Details");

            // Pass the search results to the next controller
            showTrainDetailsController controller = loader.getController();

            // Convert searchResults (List) to ObservableList
            ObservableList<Train> observableSearchResults = FXCollections.observableArrayList(searchResults);
            controller.displayTrainData(observableSearchResults);

            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Error", "Unable to open the Train Details window.");
        }
    }


    private void showAlert(String title, String content) {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
    public void bookTicketsOnAction(ActionEvent event)throws IOException{
        FXMLLoader loader=new FXMLLoader(getClass().getResource("bookTicket.fxml"));
        Parent root=loader.load();
        Stage stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        stage.setScene((new Scene(root)));

    }
    public void cancelTicketOnAction(ActionEvent event)throws IOException{
        FXMLLoader loader=new FXMLLoader(getClass().getResource("cancelTicket.fxml"));
        Parent root=loader.load();
        Stage stage=(Stage)((Node)event.getSource()).getScene().getWindow();

        stage.setScene((new Scene(root)));

    }
    public void myTicketsOnAction(ActionEvent event)throws IOException{
        FXMLLoader loader=new FXMLLoader(getClass().getResource("myTickets.fxml"));
        Parent root=loader.load();
        Stage stage=(Stage)((Node)event.getSource()).getScene().getWindow();

        stage.setScene((new Scene(root)));

    }
    public void logoutButtonOnAction(ActionEvent event) throws IOException {

        FXMLLoader loader = new FXMLLoader(getClass().getResource("UserLoginPage.fxml"));
        Parent root = loader.load();
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));

    }
}



