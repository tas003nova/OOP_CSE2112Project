package com.example.railwayticketmanagementsystem;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;

import java.sql.*;

public class UpdateTrainDetailsController {

    @FXML
    private TextField serialNoField;
    @FXML
    private TextField trainNoField;
    @FXML
    private TextField trainNameField;
    @FXML
    private TextField departureField;
    @FXML
    private TextField destinationField;
    @FXML
    private TextField classField;
    @FXML
    private TextField priceField;
    @FXML
    private TextField arrivalField;
    @FXML
    private TextField departureTimeField;
    @FXML
    private TextField availableTicketsField;

    private String trainNo;  // To store the train number being updated

    // Method to load train details from the database
    public void loadTrainDetails(String trainNo) {
        this.trainNo = trainNo;

        String url = "jdbc:mysql://localhost:3306/railway";
        String username = "root";
        String password = "mysql03";

        String query = "SELECT * FROM trains WHERE train_no = ?";

        try (Connection conn = DriverManager.getConnection(url, username, password);
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, trainNo);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                // Populate the fields with data from the database
                serialNoField.setText(rs.getString("serial_no"));
                trainNoField.setText(rs.getString("train_no"));
                trainNameField.setText(rs.getString("train_name"));
                departureField.setText(rs.getString("departure"));
                destinationField.setText(rs.getString("destination"));
                classField.setText(rs.getString("class"));
                priceField.setText(rs.getString("price"));
                arrivalField.setText(rs.getString("arrival"));
                departureTimeField.setText(rs.getString("departure_time"));
                availableTicketsField.setText(rs.getString("available_tickets"));
            } else {
                showAlert("Error", "Train details not found.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to handle the "Update Details" button
    @FXML
    public void handleUpdateDetails() {
        String url = "jdbc:mysql://localhost:3306/railway";
        String username = "root";
        String password = "mysql03";

        String query = "UPDATE trains SET train_name = ?, departure = ?, destination = ?, class = ?, price = ?, " +
                "arrival = ?, departure_time = ?, available_tickets = ? WHERE train_no = ?";

        try (Connection conn = DriverManager.getConnection(url, username, password);
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            // Set the updated values from the form
            pstmt.setString(1, trainNameField.getText());
            pstmt.setString(2, departureField.getText());
            pstmt.setString(3, destinationField.getText());
            pstmt.setString(4, classField.getText());
            pstmt.setString(5, priceField.getText());
            pstmt.setString(6, arrivalField.getText());
            pstmt.setString(7, departureTimeField.getText());
            pstmt.setString(8, availableTicketsField.getText());
            pstmt.setString(9, trainNo);

            int rowsAffected = pstmt.executeUpdate();

            if (rowsAffected > 0) {
                showAlert("Success", "Train details updated successfully!");
            } else {
                showAlert("Error", "Failed to update train details.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Helper method to show an alert
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
