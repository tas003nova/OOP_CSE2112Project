package com.example.railwayticketmanagementsystem;

public class Train {

    private String serialNo;      // Added serialNo field
    private String trainNo;
    private String trainName;
    private String departure;
    private String arrival;
    private double price;
    private String trainClass;
    private int availableTickets;
    private String destination;   // Field for destination
    private String departureTime; // Field for departure time

    // Updated constructor to include serialNo, destination, and departureTime
    public Train(String serialNo, String trainNo, String trainName, String departure, String destination,
                 String arrival, String departureTime, double price, String trainClass, int availableTickets) {

        this.serialNo = serialNo;
        this.trainNo = trainNo;
        this.trainName = trainName;
        this.departure = departure;
        this.destination = destination;  // Initialize destination
        this.arrival = arrival;
        this.departureTime = departureTime;  // Initialize departureTime
        this.price = price;
        this.trainClass = trainClass;
        this.availableTickets = availableTickets;
    }

    // Getters and Setters for all fields

    public String getSerialNo() {
        return serialNo;
    }

    public void setSerialNo(String serialNo) {
        this.serialNo = serialNo;
    }

    public String getTrainNo() {
        return trainNo;
    }

    public void setTrainNo(String trainNo) {
        this.trainNo = trainNo;
    }

    public String getTrainName() {
        return trainName;
    }

    public void setTrainName(String trainName) {
        this.trainName = trainName;
    }

    public String getDeparture() {
        return departure;
    }

    public void setDeparture(String departure) {
        this.departure = departure;
    }

    public String getArrival() {
        return arrival;
    }

    public void setArrival(String arrival) {
        this.arrival = arrival;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getTrainClass() {
        return trainClass;
    }

    public void setTrainClass(String trainClass) {
        this.trainClass = trainClass;
    }

    public int getAvailableTickets() {
        return availableTickets;
    }

    public void setAvailableTickets(int availableTickets) {
        this.availableTickets = availableTickets;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public String getDepartureTime() {
        return departureTime;
    }

    public void setDepartureTime(String departureTime) {
        this.departureTime = departureTime;
    }
}
