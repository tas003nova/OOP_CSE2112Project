package com.example.railwayticketmanagementsystem;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.chart.PieChart;
import javafx.scene.control.Label;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ShowIncomeController {

    @FXML
    private Label totalIncomeLabel; // This is the label to display total income

    @FXML
    private PieChart incomePieChart; // This is the pie chart to display income distribution

    public void initialize() {
        fetchAndDisplayIncomeData();
    }

    private void fetchAndDisplayIncomeData() {
        // Update these variables with your database credentials
        String url = "jdbc:mysql://localhost:3306/railway";
        String user = "root";
        String password = "mysql03";

        try (Connection connection = DriverManager.getConnection(url, user, password)) {
            // Fetch total income
            String totalIncomeQuery = "SELECT SUM(price) AS total_income FROM tickets";
            try (PreparedStatement totalStmt = connection.prepareStatement(totalIncomeQuery);
                 ResultSet totalResultSet = totalStmt.executeQuery()) {
                if (totalResultSet.next()) {
                    double totalIncome = totalResultSet.getDouble("total_income");
                    totalIncomeLabel.setText("Total Income: $" + totalIncome);
                }
            }

            // Fetch income per train for the pie chart
            String trainIncomeQuery = "SELECT train_name, SUM(price) AS train_income FROM tickets GROUP BY train_name";
            try (PreparedStatement trainStmt = connection.prepareStatement(trainIncomeQuery);
                 ResultSet trainResultSet = trainStmt.executeQuery()) {
                ObservableList<PieChart.Data> pieChartData = FXCollections.observableArrayList();
                while (trainResultSet.next()) {
                    String trainName = trainResultSet.getString("train_name");
                    double trainIncome = trainResultSet.getDouble("train_income");
                    pieChartData.add(new PieChart.Data(trainName, trainIncome));
                }
                incomePieChart.setData(pieChartData); // Populate the pie chart
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
