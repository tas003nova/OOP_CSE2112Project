
package com.example.railwayticketmanagementsystem;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class UserLoginPageController {
    @FXML
    private TextField usernameTextField;
    @FXML
    private PasswordField passwordTextField;
    @FXML
    private Label loginMessageLabel;
    @FXML
    private Button loginButton;
    @FXML
    private Button registerButton;
    public static String loggedInUsername;
    public static int loggedInUserId;
    public void loginButtonOnAction(ActionEvent event){

        if(!usernameTextField.getText().isBlank() && !passwordTextField.getText().isBlank()){
            validateLogin(event);

        }
        else{
            loginMessageLabel.setText("Please enter username and password");


        }

    }
    public void validateLogin(ActionEvent event){
        DatabaseConnection connectNow=new DatabaseConnection();
        Connection connectDB=connectNow.getConnection();

        String verifyLogin = "SELECT count(1) FROM user_account where username= ? AND password= ?";
        try (PreparedStatement statement = connectDB.prepareStatement(verifyLogin)) {
            statement.setString(1, usernameTextField.getText());
            statement.setString(2, passwordTextField.getText());
            try (ResultSet queryResult = statement.executeQuery()) {
                if (queryResult.next() && queryResult.getInt(1) == 1) {
                    loginMessageLabel.setText("Congratulations! You have successfully logged in.");
                    loggedInUsername = usernameTextField.getText();

                    // Retrieve account_id
                    try (PreparedStatement stmt = connectDB.prepareStatement("SELECT account_id FROM user_account WHERE username = ?")) {
                        stmt.setString(1, usernameTextField.getText());
                        try (ResultSet rs = stmt.executeQuery()) {
                            if (rs.next()) {
                                loggedInUserId = rs.getInt("account_id");
                            }
                        }
                    }

                    // Load trainSearch.fxml
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("trainSearch.fxml"));
                    Parent root = loader.load();

                    trainSearchController trainSearchController = loader.getController();
                    trainSearchController.setUsername(loggedInUsername);

                    Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                    stage.setScene(new Scene(root));
                } else {
                    loginMessageLabel.setText("Invalid login. Please try again.");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            loginMessageLabel.setText("An error occurred. Please try again.");
        }

    }
    public void registerButtonOnAction(ActionEvent event) throws IOException {
        FXMLLoader loader=new FXMLLoader(getClass().getResource("register.fxml"));
        Parent root=loader.load();
        Stage stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        stage.setTitle("Search Train");
        stage.setScene((new Scene(root)));

    }
    public void backButtonOnAction(ActionEvent event) throws IOException {
        FXMLLoader loader=new FXMLLoader(getClass().getResource("hello-view.fxml"));
        Parent root=loader.load();
        Stage stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        stage.setScene((new Scene(root)));

    }


}


