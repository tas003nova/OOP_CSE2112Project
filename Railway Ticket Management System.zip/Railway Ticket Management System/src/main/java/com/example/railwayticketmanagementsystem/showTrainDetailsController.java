package com.example.railwayticketmanagementsystem;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

public class showTrainDetailsController {

    @FXML
    private TableView<Train> trainTable;

    @FXML
    private TableColumn<Train, String> train_no_col;

    @FXML
    private TableColumn<Train, String> train_name_col;

    @FXML
    private TableColumn<Train, String> departure_col;

    @FXML
    private TableColumn<Train, String> arrival_col;

    @FXML
    private TableColumn<Train, String> departure_time_col;

    @FXML
    private TableColumn<Train, String> arrival_time_col;

    @FXML
    private TableColumn<Train, String> class_col;

    @FXML
    private TableColumn<Train, Double> price_col;

    private ObservableList<Train> trainList = FXCollections.observableArrayList();

    /**
     * Initialize method is called automatically after the FXML file is loaded.
     */
    @FXML
    public void initialize() {
        // Set up the table columns with the corresponding Train properties
        train_no_col.setCellValueFactory(new PropertyValueFactory<>("trainNo"));
        train_name_col.setCellValueFactory(new PropertyValueFactory<>("trainName"));
        departure_col.setCellValueFactory(new PropertyValueFactory<>("departure"));
        arrival_col.setCellValueFactory(new PropertyValueFactory<>("arrival"));
        departure_time_col.setCellValueFactory(new PropertyValueFactory<>("departureTime"));
        arrival_time_col.setCellValueFactory(new PropertyValueFactory<>("arrivalTime"));
        class_col.setCellValueFactory(new PropertyValueFactory<>("trainClass"));
        price_col.setCellValueFactory(new PropertyValueFactory<>("price"));

        // Bind the observable list to the TableView
        trainTable.setItems(trainList);
    }

    /**
     * Add a list of trains to the TableView for display.
     *
     * @param trains The list of trains to display.
     */
    public void displayTrainData(ObservableList<Train> trains) {
        trainList.clear(); // Clear the previous data
        trainList.addAll(trains); // Add the new list of trains
    }

    /**
     * Handles the "Back" button action.
     *
     * @param event The action event triggered by the button click.
     */
    @FXML
    private void backButtonOnAction(ActionEvent event) {
        // Close the current stage (window)
        Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        currentStage.close();
    }
}



