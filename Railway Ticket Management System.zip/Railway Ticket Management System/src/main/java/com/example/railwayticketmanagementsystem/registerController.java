package com.example.railwayticketmanagementsystem;


import javafx.event.ActionEvent;
import javafx.fxml.FXML;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.ResourceBundle;

import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class registerController {

    @FXML
    private Label registrationMessageLabel;
    @FXML
    private PasswordField setPasswordField;
    @FXML
    private PasswordField confirmPasswordField;
    @FXML
    private Label confirmPasswordLabel;
    @FXML
    private TextField firstnameTextField;
    @FXML
    private TextField lastnameTextField;
    @FXML
    private TextField usernameTextField;



    public void registerButtonOnAction (ActionEvent event){
        if(setPasswordField.getText().equals(confirmPasswordField.getText())){
            registerUser();
            confirmPasswordLabel.setText("");
        }
        else {
            confirmPasswordLabel.setText("Password does not match");
            registrationMessageLabel.setText("");

        }

    }
    public void registerUser(){
        DatabaseConnection  connectNow = new DatabaseConnection();
        Connection connectDB = connectNow.getConnection();
        String firstname = firstnameTextField.getText();
        String lastname = lastnameTextField.getText();
        String username =usernameTextField.getText();
        String password = setPasswordField.getText();

        String query ="INSERT INTO user_account (firstname,lastname, username, password) VALUES (?, ?, ?,?)";
        try {
            PreparedStatement statement = connectDB.prepareStatement(query);
            statement.setString(1, firstname);
            statement.setString(2, lastname);
            statement.setString(3, username);
            statement.setString(4, password);
            statement.executeUpdate();

            registrationMessageLabel.setText("User has been registered succesfully!");
        }
        catch (Exception e){
            e.printStackTrace();
            e.getCause();
        }

    }
    public void backButtonOnAction(ActionEvent event) throws IOException {
        FXMLLoader loader=new FXMLLoader(getClass().getResource("UserLoginPage.fxml"));
        Parent root=loader.load();
        Stage stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        stage.setScene((new Scene(root)));
    }

}
