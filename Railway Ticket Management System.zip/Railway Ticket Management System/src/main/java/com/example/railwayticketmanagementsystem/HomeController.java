package com.example.railwayticketmanagementsystem;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;
import java.io.IOException;
import javafx.scene.control.Label;

public class HomeController {
    @FXML
    private Button adminButton;

    @FXML
    private Button userButton;

    // Handle Admin Button
    @FXML
    private void handleAdminButton() {
        try {
            // Load the Admin Login Page
            FXMLLoader loader = new FXMLLoader(getClass().getResource("AdminLoginPage.fxml"));
            Scene adminScene = new Scene(loader.load());
            Stage stage = (Stage) adminButton.getScene().getWindow();
            stage.setScene(adminScene);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Handle User Button
    @FXML
    private void handleUserButton() {
        try {
            // Load the User Login Page (optional for now)
            FXMLLoader loader = new FXMLLoader(getClass().getResource("UserLoginPage.fxml"));
            Scene userScene = new Scene(loader.load());
            Stage stage = (Stage) userButton.getScene().getWindow();
            stage.setScene(userScene);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}